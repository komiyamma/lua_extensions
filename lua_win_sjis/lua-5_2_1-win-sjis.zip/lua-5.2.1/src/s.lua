function outacl(acl)
  if acl == win32.INVALID_HANDLE_VALUE then
    print("INVALID_HANDLE_VALUE")
  else
    n = win32.getace(acl)
    for i = 0, (n - 1), 1 do
      print(win32.fileacetos(win32.getace(acl, i)))
    end
  end
end

function outsd(sd)
  print("sd:", sd)
  b, o, id = win32.getsecuritydescriptorowner(sd)
  print("success:", b, "owned:", o, "id:", id)
  print(win32.strerror())
  u, d, t = win32.lookupaccountsid(nil, id)
  print("user:", u, "domain:", d, "type:", t)
  print(win32.strerror())
  b, c, r = win32.getsecuritydescriptorcontrol(sd)
  print("ctrl:", b, string.format("%x", c), r)
end

s = win32.getfilesecurity("D:\\JUNK.TXT", 0x5)
b, o, id = win32.getsecuritydescriptorowner(s)
outsd(s)
b, sacl, e, d =  win32.getsecuritydescriptorsacl(s)
print(b, sacl, e, d)
b, dacl, e, d =  win32.getsecuritydescriptordacl(s)
print(b, dacl, e, d)
outacl(dacl)
print "newsd"
s = win32.newabsolutesd();
id, d = win32.lookupaccountname(nil, "BULL")
print("id:", id, "domain:", d)
win32.setsecuritydescriptorowner(s, id, false)
print(win32.strerror())

b, o, id = win32.getsecuritydescriptorowner(s)
u, d, t = win32.lookupaccountsid(nil, id)
print("user:", u, "domain:", d, "type:", t)


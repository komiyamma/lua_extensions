#ifdef SHIFTJIS
#ifndef SHIFTJIS_H
#define SHIFTJIS_H

#define ISSJIS1(CH) \
 (((0x81 <= ((CH) & 0xff)) && (((CH) & 0xff) <= 0x9f)) || \
  ((0xe0 <= ((CH) & 0xff)) && (((CH) & 0xff) <= 0xef)))

#define ISSJIS2(CH) \
 (((0x40 <= ((CH) & 0xff)) && (((CH) & 0xff) <= 0x7e)) || \
  ((0x80 <= ((CH) & 0xff)) && (((CH) & 0xff) <= 0xfc)))

#define MAKEWC(s) \
 ((ISSJIS1((s)[0]) && ISSJIS2((s)[1])) ? \
  ((((s)[0] & 0xff) << 8) | ((s)[1] & 0xff)) : \
  (((s)[0]) & 0xff))

#define MAKEWCLM(s, l) \
 (((l >= 2) && ISSJIS1((s)[0]) && ISSJIS2((s)[1])) ? \
  ((((s)[0] & 0xff) << 8) | ((s)[1] & 0xff)) : \
  (((s)[0]) & 0xff))

#define MBLEN(p) ((ISSJIS1((p)[0]) && ISSJIS2((p)[1])) ? 2 : 1)

#define MBNEXT(p) (&((p)[MBLEN(p)]))

#define MBPREV(ep) \
  ((ISSJIS1((ep)[-2]) && ISSJIS2((ep)[-1])) ? \
   (&((ep)[-2])) : (&((ep)[-1])))

/* LexState *p */
#define LEXSTATENOTEMPTY(p) \
  (luaZ_bufflen((p)->buff) > (size_t)0)
#define LEXSTATELAST(p) \
  (((p)->buff->buffer[luaZ_bufflen(p->buff) - (size_t)1]) & 0xff)

/* luaL_Buffer *p */
#define LUABUFFERNOTEMPTY(p) \
  ((p)->n > (size_t)0)
#define LUABUFFERLAST(p) \
  (((p)->b[(p)->n - (size_t)1]) & 0xff)

#endif /* SHIFTJIS_H */
#endif /* SHIFTJIS */
